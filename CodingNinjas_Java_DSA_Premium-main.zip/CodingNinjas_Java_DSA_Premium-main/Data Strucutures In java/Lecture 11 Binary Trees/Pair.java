
public class Pair <T,V>{
	public T first;
	public V second;

}

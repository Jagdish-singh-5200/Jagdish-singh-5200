
public class BinaryTreeNode <T>{
	
	public BinaryTreeNode(T data) {
		// TODO Auto-generated constructor stub
		this.data = data;
		
	}
	public T data;
	public BinaryTreeNode<T> left;
	public BinaryTreeNode<T> right;
	

}

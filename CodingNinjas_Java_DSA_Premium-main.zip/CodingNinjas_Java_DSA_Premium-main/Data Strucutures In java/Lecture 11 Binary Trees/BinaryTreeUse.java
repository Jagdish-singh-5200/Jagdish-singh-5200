public class BinaryTreeUse {
    //takeInput generic Input
    public BinaryTreeNode<Integer> takeInput(Scanner s){
        int rootData;
        
    }
    public static void main(String[] args) {
        // BinaryTreeNode<Integer> root = new BinaryTreeNode<Integer>(1);
        // BinaryTreeNode<Integer> node1 = new BinaryTreeNode<Integer>(2);
        // BinaryTreeNode<Integer> node2 = new BinaryTreeNode<Integer>(3);
        // root.left = node1;
        // root.right = node2;
    }
    
}

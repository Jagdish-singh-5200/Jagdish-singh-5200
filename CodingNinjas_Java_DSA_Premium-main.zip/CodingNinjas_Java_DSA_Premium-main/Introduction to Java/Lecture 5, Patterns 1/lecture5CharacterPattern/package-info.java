/**
 * 
 */
/**
 * @author KSumit
 *
 */
package lecture5CharacterPattern;
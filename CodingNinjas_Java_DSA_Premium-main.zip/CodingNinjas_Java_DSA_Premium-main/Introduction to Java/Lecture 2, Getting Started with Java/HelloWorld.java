

public class HelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Hello World");
		System.out.println("\n"); //here /n is used to display in the new line
		System.out.println("This is Kumar Sumit");
		//you can also display on new line by System.out.println.
		System.out.println("this is neha kumari");
		

	}

}

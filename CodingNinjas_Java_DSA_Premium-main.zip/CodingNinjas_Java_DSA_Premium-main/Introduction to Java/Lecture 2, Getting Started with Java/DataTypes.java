

public class DataTypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c = 3*2/3;
		// will give output 2 because of associativity 3*2 will be done first, and then /3 will be done. 
		//the execution flows from left to right.
		int d = 3/3 *2; //here 3/3 is done first after that 1*2 is 2 and we get the answer. 
		System.out.print(d);
		

	}

}
